import os, hmac, hashlib, json, sqlite3, time
from urllib.parse import parse_qsl
from flask import Flask, render_template, request, jsonify
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, WebAppInfo
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, ContextTypes, MessageHandler, filters

BOT_TOKEN=os.environ.get("BOT_TOKEN","PUT_NEW_BOT_TOKEN_HERE")
WEB_APP_URL=os.environ.get("WEB_APP_URL","https://YOUR-RENDER-SERVICE.onrender.com")
DATABASE="sr_money_spin.db"
PRIZES=[4000,5000,6000,7000,8000,10000]
# Rotation needed in the browser (clockwise visual motion) to bring each prize to the fixed top pointer.
TARGET_ANGLES={10000:0,4000:60,5000:120,6000:180,7000:240,8000:300}

flask_app=Flask(__name__)

def db():
    c=sqlite3.connect(DATABASE); c.row_factory=sqlite3.Row; return c

def init_db():
    c=db()
    c.execute("""CREATE TABLE IF NOT EXISTS users(
        user_id INTEGER PRIMARY KEY, username TEXT, first_name TEXT,
        language TEXT, spin1_amount INTEGER, spin2_amount INTEGER,
        spin_count INTEGER DEFAULT 0, final_amount INTEGER,
        spin1_at TEXT, spin2_at TEXT, final_at TEXT)""")
    c.commit(); c.close()

def save_user(uid, username, first_name):
    c=db(); c.execute("""INSERT INTO users(user_id,username,first_name)
        VALUES(?,?,?) ON CONFLICT(user_id) DO UPDATE SET username=excluded.username,first_name=excluded.first_name""",
        (uid,username,first_name)); c.commit(); c.close()

def lang(uid):
    c=db(); r=c.execute("SELECT language FROM users WHERE user_id=?",(uid,)).fetchone(); c.close()
    return (r["language"] if r and r["language"] else "English")

def state(uid):
    c=db(); r=c.execute("SELECT spin_count,spin1_amount,spin2_amount,final_amount FROM users WHERE user_id=?",(uid,)).fetchone(); c.close()
    if not r: return (0,None,None,None)
    return (r["spin_count"] or 0,r["spin1_amount"],r["spin2_amount"],r["final_amount"])

def verify_init_data(init_data):
    if not init_data or BOT_TOKEN.startswith("PUT_"): return None
    pairs=dict(parse_qsl(init_data,keep_blank_values=True))
    received=pairs.pop("hash",None)
    if not received: return None
    check="\n".join(f"{k}={pairs[k]}" for k in sorted(pairs))
    secret=hmac.new(b"WebAppData",BOT_TOKEN.encode(),hashlib.sha256).digest()
    calc=hmac.new(secret,check.encode(),hashlib.sha256).hexdigest()
    if not hmac.compare_digest(calc,received): return None
    auth_date=int(pairs.get("auth_date","0"))
    if time.time()-auth_date>86400: return None
    user=json.loads(pairs["user"])
    return int(user["id"])

@flask_app.get("/")
def home(): return render_template("index.html")

@flask_app.post("/api/spin")
def api_spin():
    data=request.get_json(silent=True) or {}
    uid=verify_init_data(data.get("initData",""))
    if not uid: return jsonify(error="Invalid Telegram session"),401
    c=db()
    r=c.execute("SELECT * FROM users WHERE user_id=?",(uid,)).fetchone()
    if not r: c.close(); return jsonify(error="User not registered"),403
    count=r["spin_count"] or 0
    if count>=2: c.close(); return jsonify(error="Two spins already used"),409
    amount=__import__("random").choice(PRIZES)
    now=time.strftime("%Y-%m-%d %H:%M:%S")
    if count==0:
        c.execute("UPDATE users SET spin1_amount=?,spin1_at=?,spin_count=1 WHERE user_id=?",(amount,now,uid))
    else:
        c.execute("UPDATE users SET spin2_amount=?,spin2_at=?,spin_count=2 WHERE user_id=?",(amount,now,uid))
    c.commit(); c.close()
    return jsonify(amount=amount,target_angle=TARGET_ANGLES[amount],spin_number=count+1)

async def start(update:Update, context:ContextTypes.DEFAULT_TYPE):
    u=update.effective_user
    save_user(u.id,u.username,u.first_name)
    kb=[[InlineKeyboardButton("🚀 START NOW",callback_data="start_now")]]
    await update.message.reply_text("👑 <b>WELCOME TO SR MONEY PREMIUM SPIN BOT</b>\n\n🎡 Spin • Play • Win\n💰 Your maximum spin chances: <b>2</b>",
                                    parse_mode="HTML",reply_markup=InlineKeyboardMarkup(kb))

async def start_now(update:Update, context:ContextTypes.DEFAULT_TYPE):
    q=update.callback_query; await q.answer()
    kb=[[InlineKeyboardButton("🇬🇧 English",callback_data="lang_English")],
        [InlineKeyboardButton("🇮🇳 ಕನ್ನಡ",callback_data="lang_Kannada")],
        [InlineKeyboardButton("🇮🇳 हिन्दी",callback_data="lang_Hindi")],
        [InlineKeyboardButton("🇮🇳 తెలుగు",callback_data="lang_Telugu")],
        [InlineKeyboardButton("🇮🇳 தமிழ்",callback_data="lang_Tamil")]]
    await q.edit_message_text("🌐 <b>SELECT YOUR LANGUAGE</b>\n\nPlease choose your preferred language to continue.",
                              parse_mode="HTML",reply_markup=InlineKeyboardMarkup(kb))

async def choose_lang(update:Update, context:ContextTypes.DEFAULT_TYPE):
    q=update.callback_query; await q.answer()
    uid=q.from_user.id; language=q.data.split("_",1)[1]
    c=db(); c.execute("UPDATE users SET language=? WHERE user_id=?",(language,uid)); c.commit(); c.close()
    count,*_=state(uid)
    notice=("🎯 <b>BEFORE YOU START</b>\n\n"
            "You have a maximum of <b>2 SPIN chances</b>.\n\n"
            "You may use both chances if you want.\n"
            "After your second spin, you must select <b>ONE</b> winning amount.\n"
            "Once selected, your final winning amount will be locked and cannot be changed.\n\n"
            "Please spin responsibly and review the rules applicable to your location before participating.")
    kb=[[InlineKeyboardButton("🎡 START SPIN",web_app=WebAppInfo(url=WEB_APP_URL))]]
    await q.edit_message_text(notice,parse_mode="HTML",reply_markup=InlineKeyboardMarkup(kb))

async def webapp_data(update:Update, context:ContextTypes.DEFAULT_TYPE):
    # Reserved for future final-selection messages from the Mini App.
    pass

def main():
    init_db()
    app=Application.builder().token(BOT_TOKEN).build()
    app.add_handler(CommandHandler("start",start))
    app.add_handler(CallbackQueryHandler(start_now,pattern="^start_now$"))
    app.add_handler(CallbackQueryHandler(choose_lang,pattern="^lang_"))
    app.add_handler(MessageHandler(filters.StatusUpdate.WEB_APP_DATA,webapp_data))
    import threading
    threading.Thread(target=lambda: flask_app.run(host="0.0.0.0",port=int(os.environ.get("PORT","10000")),debug=False,use_reloader=False),daemon=True).start()
    print("SR MONEY BOT + MINI APP RUNNING")
    app.run_polling()

if __name__=="__main__": main()
