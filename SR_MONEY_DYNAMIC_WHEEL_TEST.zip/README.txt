SR MONEY DYNAMIC WHEEL — TEST PROTOTYPE

This version does NOT use pre-recorded spin videos.
The Telegram Mini App animates the wheel in real time with JavaScript.

Files:
- app.py: Telegram bot + Flask Mini App server
- templates/index.html: smooth wheel animation
- static/background.png: fixed page artwork
- static/wheel_layer.png: rotating wheel layer
- static/fixed_pointer.png: fixed pointer + center
- requirements.txt
- render.yaml

Important:
1. Set BOT_TOKEN as a Render environment variable. Never paste it into chat.
2. Set WEB_APP_URL to the exact HTTPS URL of the Render web service, e.g. https://your-service.onrender.com
3. The Mini App URL must be HTTPS for Telegram.
4. This prototype stores the first two spin results in SQLite.
5. It does not yet implement the final selection/withdrawal module.

The uploaded artwork is 1261x1536. It is not a native 4K source, so this prototype does not claim true 4K detail.
